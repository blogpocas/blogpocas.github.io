---
layout: post
date: 2021-11-28 21:52:00
title: "Flaws in methods in @fabiocaccamo/utils.js"
tags: [Research]
author:
  - Jeongwon Jo

---
## Summary

On the night of November 25, 2021, I  was analyzing a method in utils.js and found something that could be exploited. This can be very dangerous for inexperienced developers. 😢

---
## Reporting  Timeline (KTC)

- 2021-11-25 21h 52m : Reported this issue via the snyk
- 2021-11-26 00h 49m : Confirmation of Received Disclosure for @fabiocaccamo/utils.js by [Colin Ife](mailto:colin.ife@snyk.io) (Security Analyst)
- 2021-11-26 00h 53m : Requested to provide patch information by [Colin Ife](mailto:colin.ife@snyk.io) (Security Analyst)