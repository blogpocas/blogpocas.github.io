---
layout: post
date: 2021-11-17 23:00:11
title: "CENSORED in Rakuten VDP"
categories: Bug Bounty
tags: [Bug Bounty]
password: rxss
message: Encrypt
author:
  - Jeongwon Jo

---
## Summary

I bypassed an `waf` and triggered a `Reflected XSS` on Rakuten VDP at dawn On November 17, 2021, at 10:36. And this was reported by Bug Crowd.

---
## Platform(s) Affected

```txt
https://outils.fr.shopping.rakuten.com/waf_error.html
```

---
## Description

![WAF.png](https://github.com/blogpocas/DATA/blob/main/BB/Rakuten%20VDP/waf_error/WAF.png?raw=true)

```txt
https://fr.shopping.rakuten.com/connect?url=%22%3E%3Ciframe%20src=%22data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b%22%3E%3C/iframe%3E
```
The above URL is an `XSS` vulnerability discovered about a month ago. I connect to the above URL, i can see that `WAF` is caught. In fact, it was to check whether the previously reported vulnerability was properly patched.

![waf_vector.png](https://github.com/blogpocas/DATA/blob/main/BB/Rakuten%20VDP/waf_error/waf_vector.png?raw=true)

When I looked closely at the URL and screen, the value of the `_event_transid` parameter was displayed on the web page as it is.

![xss-waf.png](https://github.com/blogpocas/DATA/blob/main/BB/Rakuten%20VDP/waf_error/xss-waf.png?raw=true)

```txt
https://outils.fr.shopping.rakuten.com/waf_error.html?_event_transid=asdf%3Cimg%20src=%22x%22//onerror=alert(origin)%3E
```
So, I just insert the XSS PoC as the value of the `_event_transid` parameter, it does not get caught in `WAF`, and you can see that the input value is inserted as it is and triggers `XSS`. LoL

```javascript
if ((new URL(window.location.href)).searchParams.get("_event_transid") !== undefined) document.write((new URL(window.location.href)).searchParams.get("_event_transid"));
```
After checking the code, the JavaScript was written as above, so if I passed the `XSS PoC` as the `_event_transid` parameter value, it was inserted as it is. Yes So this is why it was triggered an `xss`

---
## Reporting Timeline

- 2021-11-17 22h 36m : Found a Reflected XSS via WAF Bypass in waf_error.html
- 2021-11-17 22h 43m : Reported this issue via the Bugcrowd.
- 2021-11-18 03h 20m : Changed the state to Triaged by ChickenJoe

---