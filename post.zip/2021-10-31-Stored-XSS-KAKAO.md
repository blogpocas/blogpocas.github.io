---
title: CENSORED in mail.kakao.com
date: 2021-10-31 00:00:00
tags: Bug Bounty
categories: Bug Bounty
password: sxss
mathjax: true # add this statement, MathJax will be enabled in this post.
message: Encrypt
---
## Summary

On the evening of October 31, 2021, I bypassed sanitizer and triggered the Stored XSS Vulnerability in the mail.kakao.com!

---
## Description

![](https://github.com/blogpocas/DATA/blob/main/BB/Kakao/S%20XSS%20via%20Sanitizer%20Bypass%20in%20mail.kakao.com/1.png?raw=true)

```jsx
<script>alert(1)</script>
<img src=x onerror=alert(1)>
```
In the mail.kakao.com, If the above payload is delivered as HTML, XSS vulnerable tags and attributes are removed by Sanitizer, and you can see that it responds to XSS.

![](https://github.com/blogpocas/DATA/blob/main/BB/Kakao/S%20XSS%20via%20Sanitizer%20Bypass%20in%20mail.kakao.com/2.png?raw=true)

While checking various values, it was confirmed that when a specific PoC was inserted in the process of analyzing the principle of operation of the Sanitizer, the Sanitizer was bypassed and XSS occurred. This is a technique for escaping the Sanitizer process using templates and noscript tags.

----
## Proof of Concept
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/Kakao/S%20XSS%20via%20Sanitizer%20Bypass%20in%20mail.kakao.com/S%20XSS.mov?raw=true" type="video/mp4">
</video>

```html
<template><noscript><a title="</noscript></template><iframe srcdoc='<svg onload=top.alert(top.origin)>'></iframe>"></a></noscript></template>
```

After writing the above PoC as the content of the email, send the email, and read the email to confirm that XSS occurs. By exploiting this vulnerability, a script can be executed in the browser of any user who uses the following mail.

---
## Reporting Timeline

- 2021-10-31 21h 20m : Found a Stored Cross-Site Scripting via sanitizer bypass in mail.kakao.com.
- 2021-10-31 22h 34m : Reported this issue via the Kisa.
- 2021-12-10 17h 05m : Validated this issue by Kakao Information Security Team Manager

---