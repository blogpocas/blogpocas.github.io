---
layout: post
date: 2021-12-21 20:41:00
title: "Blind SQL Injection in MartDevelopers-Inc/iResturant"
categories: Research
tags: [SQL Injection]
author:
  - Jeongwon Jo

---
## Summary

> The [iResturant](https://github.com/MartDevelopers-Inc/iResturant) is open source for web commercial use. SQL Injection occurs because iResturant does not verify email and phone parameters when registering as a member.

```php
/* (...) */
session_start();
require_once('../config/codeGen.php');
require_once('../config/config.php');
require_once('../partials/head.php');

/* Sign Up */
if (isset($_POST['Sign_Up'])) {
    $id = $sys_gen_id;
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $adr = $_POST['adr'];
    $client_country = $_POST['client_country'];
    /* Check If Passwords Match */
    if ($new_password = sha1(md5($_POST['new_password'])) != $confirm_password = sha1(md5($_POST['confirm_password']))) {
        $err  = "Passwords Do Not Match";
    } else {
        $sql = "SELECT * FROM  iResturant_Customer  WHERE  (email='$email' || phone = '$phone')  ";
        $res = mysqli_query($mysqli, $sql);
        if (mysqli_num_rows($res) > 0) {
            $row = mysqli_fetch_assoc($res);
            if ($email == $row['email'] || $phone == $row['phone']) {
                $err =  "A Client Account With This Email Or Phone Number Already Exists";
            }
        } 
/* (...) */
// https://github.com/MartDevelopers-Inc/iResturant/blob/main/views/my_signup.php#L31L40
```
The code above is the code for the subscription logic. If you look at the source code of the subscription logic, you can see that it gets the email and phone parameter values and puts them in SQL Query. This causes SQL Injection because are not using Prepared Statement.

![](https://github.com/blogpocas/DATA/blob/main/BB/iResturant/SQL%20Injection/1.png?raw=true)
I entered user information as above. Enter SQL Injection PoC as email value

![](https://github.com/blogpocas/DATA/blob/main/BB/iResturant/SQL%20Injection/2.png?raw=true)
After sending data, I can see that the Sleep phenomenon occurs for 5 seconds. It can leak server information by using Blind SQL Injection technique!

---
## Proof of Concept

```txt
1. Open the http://<hostname>/iResturant/views/my_signup.php
2. Change the input tag type to text, enter "a' AND (SELECT 8666 FROM (SELECT(SLEEP(5)))hhmy) AND 'ROfB'='ROfB" as the value of the email, and enter another form.
3. SQL Injection occurs when you try to join
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/iResturant/SQL%20Injection/sql.mov?raw=true" type="video/mp4">
</video>


---
## Reporting Timeline

- 2021-12-21 21h 05m : Reported this issue via the [MITRE](https://cve.mitre.org/)

---