---
title: Open Redirect in nid.naver.com (N/A)
date: 2021-10-10 00:00:00
tags: Bug Bounty
categories: Bug Bounty
password: or
mathjax: true # add this statement, MathJax will be enabled in this post.
message: Encrypt
---
## Summary

On the night of October 10, 2021, I was analyzing the front-end code to find the '1-Click Account Takeover' vulnerability in Naver member (a.k.a nid.naver.com). While analyzing the code, I found the `XSS` vector and tried to chain it with the `1-Click Account Takeover` attack, but failed by the `CSP`, and ended up with the `1-Click Open Redirect` vulnerability.

---

## Platform(s) Affected

```txt
https://nid.naver.com/nidlogin.login
```

The `1-Click Open Redirect` vulnerability occurs in the above `URL`.

---
## Description

![https://user-images.githubusercontent.com/49112423/136699506-0500667f-cb17-438b-b5e1-cf7f1393e11a.png](https://user-images.githubusercontent.com/49112423/136699506-0500667f-cb17-438b-b5e1-cf7f1393e11a.png)

I check the source code in Naver login, you can see that there is a hidden parameter called `failUrl` as shown above.

![https://user-images.githubusercontent.com/49112423/136699651-abc11e76-bb01-49b5-9e20-9f8e6622580e.png](https://user-images.githubusercontent.com/49112423/136699651-abc11e76-bb01-49b5-9e20-9f8e6622580e.png)

By passing other domains as the `failUrl` parameter value, it was confirmed that the origin check was not performed unlike the `url` parameter. Now let's see where and how the value of `failUrl` is used.

```jsx
if (isObjExist('back')) {
    if (isObjExist("failUrl")&&getObjValue("failUrl")!="") {
        addNormalEvent('back',function() { location.href=getObjValue("failUrl");});
    } else {
        try {
            if (!document.referrer) {
                addNormalEvent('back',function() { window.close();});
            } else if (document.referrer.includes("nid.naver.com/nidlogin.login")) {
                addNormalEvent('back',function() { location.href="https://nid.naver.com/nidlogin.login?svctype=262144";});
            } else {
                addNormalEvent('back',function() { history.back();});
            }
        } catch (e) {
            addNormalEvent('back',function() { history.back();});
        }
    }
}
// source code url : https://nid.naver.com/login/js/v2/mobile/default.all.js?v=20210910
```

After connecting with the above `URL`, I found an interesting logic when I searched for `failUrl`.

```javascript
1. isObjectExist('back')
2. isObjExist("failUrl")&&getObjValue("failUrl")!=""
```
If the value of `1` is true and the value of `2` is also true, the `addNormalEvent()` function is called and the values of `back` and `failUrl` are passed as argument values.

```javascript
function addNormalEvent(nclickId,func) {
    if (isObjExist(nclickId)) {
        var targetElement = $(nclickId);
        if(targetElement.addEventListener) {
            targetElement.addEventListener("click", func);
        } else {
            targetElement.attachEvent("onclick", func);
        }
    }
}
```
I look at the `addNormalEvent()` function, I can see that the `Dom` for the first argument value is obtained, and the second argument value is passed to the imported DOM as the `click` or `onclick` attribute.

```javascript
function getObjValue(objName) {
    if (isObjExist(objName)) {
        return $(objName).value;
    }
    return "";
}
```
The `getObjValue()` function gets a value from `Dom` that has the same id value as the argument value, and returns the value.

```javascript
addNormalEvent('back',function() { location.href=getObjValue("failUrl");});
```
Here, the `addNormalEvent()` function is called as above. When the above code is executed, you can see that the function is being passed to the tag with the id `back` as the `click` or `onclick` attribute. Also, the passed function is a function that simply redirects to the value of `failUrl` using `location.href`.
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/Naver/Open%20Redirect%20in%20nid.naver.com/Open%20Redirect.mov?raw=true" type="video/mp4">
</video>

```html
https://nid.naver.com/nidlogin.login?svctype=262144&failUrl=https://google.com
https://nid.naver.com/nidlogin.login?svctype=262144&failUrl=https://accounts.kakao.com
https://nid.naver.com/nidlogin.login?svctype=262144&failUrl=https://pocas.kr
```
Therefore, you can redirect to the desired domain by passing the desired domain as the value of `failUrl` and clicking the `back` button. The above video shows how the `1-Click Open Redirect` vulnerability occurs.

But there is something more important here. It redirects the value of `failUrl` using `location.href`. So if you use the `javascript` scheme, you can also trigger `XSS`.

![https://user-images.githubusercontent.com/49112423/136700604-5a303859-e73f-40a4-bebe-8c01d6a7edc4.png](https://user-images.githubusercontent.com/49112423/136700604-5a303859-e73f-40a4-bebe-8c01d6a7edc4.png)

So, I tried triggering after passing `javascript:alert(1)` as the value of `failUrl`, but I was able to confirm that it was blocked by `CSP`. If the `CSP` cannot be bypassed, the `1-Click Account Takeover` attack cannot be chained, so it is just finished with `N/A`.

---
## Reporting Timeline

- 2021-10-11 12h 23m : Found an Open Redirect in nid.naver.com
- 2021-10-11 12h 37m : Reported this issue via the NBB.
- 2021-10-12 14h 59m : Changed the state to 1st review by sangjinYun
- 2021-10-12 15h 22m : Changed the state to N/A by sangjinYun

---