---
layout: post
date: 2021-12-15 23:41:00
title: "Stored XSS in meetecho/janus-gateway"
categories: Research
tags: [Research, XSS, CVE]
author:
  - Jeongwon Jo

---
## Summary

> The [Janus](https://github.com/meetecho/janus-gateway) is an open source, general purpose, WebRTC server designed and developed by Meetecho and 6.1K stars for this open source! When sending a private message in a chat plugin provided by Janus, XSS occurs.

```javascript
function sendPrivateMsg(username) {
	var display = participants[username];
	if(!display)
		return;
	bootbox.prompt("Private message to " + display, function(result) {
		if(result && result !== "") {
			var message = {
				textroom: "message",
				transaction: randomString(12),
				room: myroom,
				to: username,
				text: result
			};
			textroom.data({
				text: JSON.stringify(message),
				error: function(reason) { bootbox.alert(reason); },
				success: function() {
					$('#chatroom').append('<p style="color: purple;">[' + getDateString() + '] <b>[whisper to ' + display + ']</b> ' + result);
					$('#chatroom').get(0).scrollTop = $('#chatroom').get(0).scrollHeight;
				}
			});
		}
	});
	return;
}
// https://github.com/meetecho/janus-gateway/blob/v0.11.5/html/textroomtest.js#L340
```
The sendPrivateMsg() method is a method that sends a message privately to a specific user. However, if you look at the Success callback, the value of the result parameter is added to the DOM without verification. This means that HTML tags can be injected, thereby creating an XSS vulnerability on the chat window.

---
## Proof of Concept

```txt
1. Open the https://janus.conf.meetecho.com/textroomtest.html * 2
2. Click the Start button * 2 (Simultaneous access to the chat window with two windows)
3. Click Participants, use the private chat feature and enter <img src=x onerror=alert(document.domain)> or <a href="javascript:alert(1)">xss</a>.
4. Then XSS occurs in the chat window.
```
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/blob/main/BB/Janus/Stored%20XSS/XSS.mov?raw=true" type="video/mp4">
</video>

---
## Reporting Timeline

- 2021-12-14 21h 48m : Reported this issue via the [huntr](https://www.huntr.dev/)
- 2021-12-15 22h 11m : Validated this issue by janus-gateway maintainer
- 2021-12-15 22h 11m : Patched by janus-gateway maintainer
- 2021-12-11 00h 21m : Assign a CVE-2021-4124

---
## Reference

- [Github Commit](https://github.com/meetecho/janus-gateway/commit/f62bba6513ec840761f2434b93168106c7c65a3d)
- [Huntr](https://www.huntr.dev/bounties/a6ca142e-60aa-4d6f-b231-5d1bcd1b7190/)
- [Mitre](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-4124)
- [NVD](https://nvd.nist.gov/vuln/detail/CVE-2021-4124)

---